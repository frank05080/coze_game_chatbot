__all__ = ["Infer"]
from .bpu_infer_lib import Infer